const dynamic = {
    init: () => {
        alert('dynamic test');
    }
};

export default dynamic;
