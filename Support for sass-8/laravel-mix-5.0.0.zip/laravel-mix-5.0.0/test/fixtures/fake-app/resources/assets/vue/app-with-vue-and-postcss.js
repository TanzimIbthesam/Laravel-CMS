import 'vue';
import BasicWithPostCss from './BasicWithPostCss.vue';

new Vue({
    components: {
        BasicWithPostCss
    }
}).$mount('#app');
