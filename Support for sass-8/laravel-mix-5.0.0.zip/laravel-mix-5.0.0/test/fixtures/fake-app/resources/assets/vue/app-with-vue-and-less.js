import 'vue';
import BasicWithLess from './BasicWithLess.vue';

new Vue({
    components: {
        BasicWithLess
    }
}).$mount('#app');
