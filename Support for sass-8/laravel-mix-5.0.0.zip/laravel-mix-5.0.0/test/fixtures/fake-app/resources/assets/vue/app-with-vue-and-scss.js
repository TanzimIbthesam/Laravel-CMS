import 'vue';
import BasicWithScss from './BasicWithScss.vue';

new Vue({
    components: {
        BasicWithScss
    }
}).$mount('#app');
