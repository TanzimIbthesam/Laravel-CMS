import 'vue';
import BasicWithIndentedSass from './BasicWithIndentedSass.vue';

new Vue({
    components: {
        BasicWithIndentedSass
    }
}).$mount('#app');
