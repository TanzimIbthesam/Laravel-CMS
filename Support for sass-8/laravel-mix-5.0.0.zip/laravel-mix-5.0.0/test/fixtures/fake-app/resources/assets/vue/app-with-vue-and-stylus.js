import 'vue';
import BasicWithStylus from './BasicWithStylus.vue';

new Vue({
    components: {
        BasicWithStylus
    }
}).$mount('#app');
