import 'vue';
import BasicWithCss from './BasicWithCss.vue';

new Vue({
    components: {
        BasicWithCss
    }
}).$mount('#app');
