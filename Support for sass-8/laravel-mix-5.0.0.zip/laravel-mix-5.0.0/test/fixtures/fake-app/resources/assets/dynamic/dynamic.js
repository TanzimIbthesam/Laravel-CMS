import('./dynamic-module').then(module => module.init());
