class AutomaticComponent {
    /**
     * Create a new component instance.
     */
    constructor() {
        this.passive = true;
    }
}

module.exports = AutomaticComponent;
