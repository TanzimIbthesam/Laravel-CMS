module.exports = {
    plugins: {
        'postcss-custom-properties': {}
    }
};
